This program is mainly composed of following parts:
A)clear: from line 20 to line 38, it clears HTML canvas and the temporary dataset stored within program.
B) save and continue: from line 41 to line 69, it calls function for download and prompts user for next graph input.
C) store points: from line 127 to line 130, it stores points in a temporary array.
D) download: from line 132 to line 150, it generates a file based on the temporary array for the browser to download.
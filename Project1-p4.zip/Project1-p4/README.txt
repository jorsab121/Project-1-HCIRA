This program mainly contains four parts:
1: Prompts user for 160 inputs.
2. Stores points internally
3: converts points array into XML format
4: outputs files.